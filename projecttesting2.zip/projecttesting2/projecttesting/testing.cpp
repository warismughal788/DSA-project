#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <limits>
using namespace std;

// ---------- Data Structure Node Definitions ----------

// Linked list node for Donors
struct DonorNode {
    int id;
    string name;
    double donationAmount;
    DonorNode* next;
    DonorNode(int _id, const string& _name, double _donation)
        : id(_id), name(_name), donationAmount(_donation), next(nullptr) {}
};

// Linked list node for Children
struct ChildNode {
    int id;
    string name;
    int age;
    string status;
    ChildNode* next;
    ChildNode(int _id, const string& _name, int _age, const string& _status)
        : id(_id), name(_name), age(_age), status(_status), next(nullptr) {}
};

// Linked list node for Students
struct StudentNode {
    int id;
    string name;
    int points;
    StudentNode* next;
    StudentNode(int _id, const string& _name, int _points = 0)
        : id(_id), name(_name), points(_points), next(nullptr) {}
};

// Stack node to record point assignments for Students
struct PointsStackNode {
    int studentId;
    int pointsAdded;
    int previousPoints;
    PointsStackNode* next;
    PointsStackNode(int _studentId, int _pointsAdded, int _previousPoints)
        : studentId(_studentId), pointsAdded(_pointsAdded), previousPoints(_previousPoints), next(nullptr) {}
};

// Queue node for Feedback messages
struct FeedbackNode {
    string donorName;
    string feedbackMessage;
    FeedbackNode* next;
    FeedbackNode(const string& _donorName, const string& _feedback)
        : donorName(_donorName), feedbackMessage(_feedback), next(nullptr) {}
};

// ---------- WelfareSystem Class Definition ----------

class WelfareSystem {
private:
    // Head pointers for linked lists
    DonorNode* donorHead;
    ChildNode* childHead;
    StudentNode* studentHead;

    // Top pointer for the points assignment stack
    PointsStackNode* pointsStackTop;

    // Front and rear pointers for the feedback queue
    FeedbackNode* feedbackFront;
    FeedbackNode* feedbackRear;

    // ----------------- File Loading Functions -----------------
    void loadDonorsFromFile() {
        ifstream file("donors.csv");
        if (!file.is_open()) {
            cerr << "Error: Unable to open donors.csv" << endl;
            return;
        }
        string line;
        while (getline(file, line)) {
            if (line.empty()) continue;
            stringstream ss(line);
            string idStr, name, donationStr;
            getline(ss, idStr, ',');
            getline(ss, name, ',');
            getline(ss, donationStr);
            int id = stoi(idStr);
            double donation = stod(donationStr);
            // Append node to linked list
            DonorNode* newDonor = new DonorNode(id, name, donation);
            if (!donorHead)
                donorHead = newDonor;
            else {
                DonorNode* temp = donorHead;
                while (temp->next)
                    temp = temp->next;
                temp->next = newDonor;
            }
        }
        file.close();
    }

    void loadChildrenFromFile() {
        ifstream file("children.csv");
        if (!file.is_open()) {
            cerr << "Error: Unable to open children.csv" << endl;
            return;
        }
        string line;
        while (getline(file, line)) {
            if (line.empty()) continue;
            stringstream ss(line);
            string idStr, name, ageStr, status;
            getline(ss, idStr, ',');
            getline(ss, name, ',');
            getline(ss, ageStr, ',');
            getline(ss, status);
            int id = stoi(idStr);
            int age = stoi(ageStr);
            ChildNode* newChild = new ChildNode(id, name, age, status);
            if (!childHead)
                childHead = newChild;
            else {
                ChildNode* temp = childHead;
                while (temp->next)
                    temp = temp->next;
                temp->next = newChild;
            }
        }
        file.close();
    }

    void loadStudentsFromFile() {
        ifstream file("students.csv");
        if (!file.is_open()) {
            cerr << "Error: Unable to open students.csv" << endl;
            return;
        }
        string line;
        while (getline(file, line)) {
            if (line.empty()) continue;
            stringstream ss(line);
            string idStr, name, pointsStr;
            getline(ss, idStr, ',');
            getline(ss, name, ',');
            getline(ss, pointsStr);
            int id = stoi(idStr);
            int points = stoi(pointsStr);
            StudentNode* newStudent = new StudentNode(id, name, points);
            if (!studentHead)
                studentHead = newStudent;
            else {
                StudentNode* temp = studentHead;
                while (temp->next)
                    temp = temp->next;
                temp->next = newStudent;
            }
        }
        file.close();
    }

    void loadFeedbackFromFile() {
        ifstream file("feedback.csv");
        if (!file.is_open()) {
            cerr << "Error: Unable to open feedback.csv" << endl;
            return;
        }
        string line;
        while (getline(file, line)) {
            if (line.empty()) continue;
            stringstream ss(line);
            string donorName, feedbackMessage;
            getline(ss, donorName, ',');
            getline(ss, feedbackMessage);
            FeedbackNode* newFeedback = new FeedbackNode(donorName, feedbackMessage);
            if (!feedbackFront)
                feedbackFront = feedbackRear = newFeedback;
            else {
                feedbackRear->next = newFeedback;
                feedbackRear = newFeedback;
            }
        }
        file.close();
    }

    // ----------------- New Helper Function -----------------
    // Checks if the given ID already exists in the specified CSV file.
    bool idExistsInFile(const string &filename, int idToCheck) {
        ifstream file(filename);
        if (!file.is_open()) {
            // If file cannot be opened, assume id does not exist.
            return false;
        }
        string line;
        while (getline(file, line)) {
            if (line.empty()) continue;
            stringstream ss(line);
            string idStr;
            if (getline(ss, idStr, ',')) {  // Read first token (ID)
                try {
                    int fileId = stoi(idStr);
                    if (fileId == idToCheck) {
                        file.close();
                        return true;
                    }
                } catch (...) {
                    continue;  // Skip malformed lines.
                }
            }
        }
        file.close();
        return false;
    }

    // ----------------- Utility Function to Clear Screen -----------------
    void clearScreen() {
#ifdef _WIN32
        system("cls");
#else
        system("clear");
#endif
    }

    // ----------------- UI Header -----------------
    void printHeader() {
        cout << "****************************************************\n";
        cout << "*                                                  *\n";
        cout << "*         WELCOME TO THE WELFARE SYSTEM            *\n";
        cout << "*                                                  *\n";
        cout << "****************************************************\n\n";
    }

public:
    WelfareSystem()
        : donorHead(nullptr), childHead(nullptr), studentHead(nullptr),
          pointsStackTop(nullptr), feedbackFront(nullptr), feedbackRear(nullptr) {
        // Load data from files into the linked lists.
        loadDonorsFromFile();
        loadChildrenFromFile();
        loadStudentsFromFile();
        loadFeedbackFromFile();
    }

    // ----- Helper Functions (Username/Password & CSV initialization) -----
    bool isValidUsername(const string& username) {
        for (char ch : username) {
            if (!isalpha(ch))
                return false;
        }
        return true;
    }

    bool isValidPassword(const string& password) {
        bool hasAlpha = false, hasDigit = false;
        for (char ch : password) {
            if (isalpha(ch))
                hasAlpha = true;
            if (isdigit(ch))
                hasDigit = true;
            if (hasAlpha && hasDigit)
                return true;
        }
        return false;
    }

    // Function to create files if they do not exist (for admin credentials)
    void initializeFiles() {
        vector<string> files = {"login.csv", "donors.csv", "children.csv", "students.csv", "feedback.csv"};
        for (const string& filename : files) {
            ofstream file(filename, ios::app);
            if (!file.is_open()) {
                cerr << "Error creating file: " << filename << endl;
            } else {
                if (filename == "login.csv" && file.tellp() == 0) {
                    file << "Admin,Admin123" << endl;
                }
                file.close();
            }
        }
    }

    // Authenticate admin using CSV file (credentials remain file-based)
    bool authenticateAdmin(const string& username, const string& password) {
        ifstream file("login.csv");
        string line, fileUsername, filePassword;
        while (getline(file, line)) {
            size_t commaPos = line.find(",");
            if (commaPos != string::npos) {
                fileUsername = line.substr(0, commaPos);
                filePassword = line.substr(commaPos + 1);
                if (username == fileUsername && password == filePassword) {
                    return true;
                }
            }
        }
        return false;
    }

    // ----------------- Functions Using Linked List, Stack, and Queue -----------------

    // 1. Add Donor (using a linked list)
    void addDonor() {
        int id;
        double donationAmount;
        cout << "\nEnter Donor ID: ";
        while (!(cin >> id) || id < 0) {
            cout << "Invalid input. Please enter a positive integer for Donor ID: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        // Check if the ID already exists in the donors file.
        if (idExistsInFile("donors.csv", id)) {
            cout << "Error: Donor with ID " << id << " already exists in file. Please try a different ID.\n";
            cin.ignore();
            return;
        }
        cin.ignore();

        cout << "Enter Donor Name: ";
        string name;
        getline(cin, name);

        cout << "Enter Donation Amount: ";
        while (!(cin >> donationAmount) || donationAmount < 0.0) {
            cout << "Invalid input. Please enter a positive donation amount: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore();

        // Create and insert new donor node at the end of the linked list.
        DonorNode* newDonor = new DonorNode(id, name, donationAmount);
        if (donorHead == nullptr)
            donorHead = newDonor;
        else {
            DonorNode* temp = donorHead;
            while (temp->next != nullptr)
                temp = temp->next;
            temp->next = newDonor;
        }

        // Append new record to file.
        ofstream file("donors.csv", ios::app);
        if (file.is_open()) {
            file << id << "," << name << "," << donationAmount << "\n";
            file.close();
        } else {
            cerr << "Error: Unable to write to donors.csv" << endl;
        }
        cout << "Donor added successfully!\n";
    }

    // 2. Display Donors
    void displayDonors() {
        if (donorHead == nullptr) {
            cout << "\nNo donor data found.\n";
            return;
        }
        cout << "\nDonors List:\nID, Name, Donation Amount\n";
        DonorNode* temp = donorHead;
        while (temp != nullptr) {
            cout << temp->id << ", " << temp->name << ", " << temp->donationAmount << "\n";
            temp = temp->next;
        }
    }

    // 3. Delete Donor
    void deleteDonor() {
        int id;
        cout << "\nEnter Donor ID to delete: ";
        while (!(cin >> id)) {
            cout << "Invalid input. Please enter an integer for Donor ID: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore();

        DonorNode* curr = donorHead;
        DonorNode* prev = nullptr;
        while (curr != nullptr && curr->id != id) {
            prev = curr;
            curr = curr->next;
        }
        if (curr == nullptr) {
            cout << "Donor with ID " << id << " not found.\n";
            return;
        }
        if (prev == nullptr)
            donorHead = curr->next;
        else
            prev->next = curr->next;
        delete curr;
        cout << "Donor deleted successfully!\n";

        // Rewrite the donors.csv file with current list.
        ofstream file("donors.csv", ios::trunc);
        if (file.is_open()) {
            DonorNode* temp = donorHead;
            while (temp != nullptr) {
                file << temp->id << "," << temp->name << "," << temp->donationAmount << "\n";
                temp = temp->next;
            }
            file.close();
        } else {
            cerr << "Error: Unable to write to donors.csv" << endl;
        }
    }

    // 4. Add Child
    void addChild() {
        int id, age;
        cout << "\nEnter Child ID: ";
        while (!(cin >> id) || id < 0) {
            cout << "Invalid input. Please enter a positive integer for Child ID: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        // Check if the ID already exists in children.csv.
        if (idExistsInFile("children.csv", id)) {
            cout << "Error: Child with ID " << id << " already exists in file. Please try a different ID.\n";
            cin.ignore();
            return;
        }
        cin.ignore();

        cout << "Enter Child Name: ";
        string name;
        getline(cin, name);

        cout << "Enter Age: ";
        while (!(cin >> age) || age < 0) {
            cout << "Invalid input. Please enter a positive integer for Age: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore();

        cout << "Enter Status: ";
        string status;
        getline(cin, status);

        ChildNode* newChild = new ChildNode(id, name, age, status);
        if (childHead == nullptr)
            childHead = newChild;
        else {
            ChildNode* temp = childHead;
            while (temp->next != nullptr)
                temp = temp->next;
            temp->next = newChild;
        }
        ofstream file("children.csv", ios::app);
        if (file.is_open()) {
            file << id << "," << name << "," << age << "," << status << "\n";
            file.close();
        } else {
            cerr << "Error: Unable to write to children.csv" << endl;
        }
        cout << "Child added successfully!\n";
    }

    // 5. Display Children
    void displayChildren() {
        if (childHead == nullptr) {
            cout << "\nNo child data found.\n";
            return;
        }
        cout << "\nChildren List:\nID, Name, Age, Status\n";
        ChildNode* temp = childHead;
        while (temp != nullptr) {
            cout << temp->id << ", " << temp->name << ", " << temp->age << ", " << temp->status << "\n";
            temp = temp->next;
        }
    }

    // 6. Add Student
    void addStudent() {
        int id;
        cout << "\nEnter Student ID: ";
        while (!(cin >> id) || id < 0) {
            cout << "Invalid input. Please enter a positive integer for Student ID: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        // Check if the ID already exists in students.csv.
        if (idExistsInFile("students.csv", id)) {
            cout << "Error: Student with ID " << id << " already exists in file. Please try a different ID.\n";
            cin.ignore();
            return;
        }
        cin.ignore();

        cout << "Enter Student Name: ";
        string name;
        getline(cin, name);

        StudentNode* newStudent = new StudentNode(id, name, 0);
        if (studentHead == nullptr)
            studentHead = newStudent;
        else {
            StudentNode* temp = studentHead;
            while (temp->next != nullptr)
                temp = temp->next;
            temp->next = newStudent;
        }
        ofstream file("students.csv", ios::app);
        if (file.is_open()) {
            file << id << "," << name << "," << 0 << "\n";
            file.close();
        } else {
            cerr << "Error: Unable to write to students.csv" << endl;
        }
        cout << "Student added successfully!\n";
    }

    // 7. Display Students
    void displayStudents() {
        if (studentHead == nullptr) {
            cout << "\nNo student data found.\n";
            return;
        }
        cout << "\nStudent List:\nID, Name, Points\n";
        StudentNode* temp = studentHead;
        while (temp != nullptr) {
            cout << temp->id << ", " << temp->name << ", " << temp->points << "\n";
            temp = temp->next;
        }
    }

    // 8. Delete Student
    void deleteStudent() {
        int id;
        cout << "\nEnter Student ID to delete: ";
        while (!(cin >> id)) {
            cout << "Invalid input. Please enter an integer for Student ID: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore();

        StudentNode* curr = studentHead;
        StudentNode* prev = nullptr;
        while (curr != nullptr && curr->id != id) {
            prev = curr;
            curr = curr->next;
        }
        if (curr == nullptr) {
            cout << "Student with ID " << id << " not found.\n";
            return;
        }
        if (prev == nullptr)
            studentHead = curr->next;
        else
            prev->next = curr->next;
        delete curr;
        cout << "Student deleted successfully!\n";

        // Rewrite the students.csv file with updated list.
        ofstream file("students.csv", ios::trunc);
        if (file.is_open()) {
            StudentNode* temp = studentHead;
            while (temp != nullptr) {
                file << temp->id << "," << temp->name << "," << temp->points << "\n";
                temp = temp->next;
            }
            file.close();
        } else {
            cerr << "Error: Unable to write to students.csv" << endl;
        }
    }

    // 9. Assign Points to Student
    void assignPoints() {
        int studentId, points;
        cout << "\nEnter Student ID to assign points: ";
        while (!(cin >> studentId)) {
            cout << "Invalid input. Enter a valid Student ID: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cout << "Enter Points to Assign: ";
        while (!(cin >> points)) {
            cout << "Invalid input. Enter valid points: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore();

        StudentNode* temp = studentHead;
        bool studentFound = false;
        while (temp != nullptr) {
            if (temp->id == studentId) {
                studentFound = true;
                int previousPoints = temp->points;
                temp->points += points;
                cout << "Points assigned successfully! Total Points: " << temp->points << "\n";
                // Record the change on the stack.
                PointsStackNode* newRecord = new PointsStackNode(studentId, points, previousPoints);
                newRecord->next = pointsStackTop;
                pointsStackTop = newRecord;
                break;
            }
            temp = temp->next;
        }
        if (!studentFound) {
            cout << "Student with ID " << studentId << " not found.\n";
        } else {
            // Rewrite the students.csv file with updated points.
            ofstream outFile("students.csv", ios::trunc);
            temp = studentHead;
            while (temp != nullptr) {
                outFile << temp->id << "," << temp->name << "," << temp->points << "\n";
                temp = temp->next;
            }
            outFile.close();
        }
    }

    // 10. Display Student Rankings
    void displayStudentRankings() {
        if (studentHead == nullptr) {
            cout << "\nNo student data found.\n";
            return;
        }
        vector<StudentNode*> students;
        StudentNode* temp = studentHead;
        while (temp != nullptr) {
            students.push_back(temp);
            temp = temp->next;
        }
        sort(students.begin(), students.end(), [](StudentNode* a, StudentNode* b) {
            return a->points > b->points;
        });
        cout << "\nStudent Rankings:\n";
        for (const auto& s : students)
            cout << "ID: " << s->id << ", Name: " << s->name << ", Points: " << s->points << "\n";
    }

    // 11. Add Feedback
    void addFeedback() {
        cin.ignore();
        cout << "\nEnter Donor Name: ";
        string donorName;
        getline(cin, donorName);
        
        // Check if feedback from this donor already exists
        FeedbackNode* temp = feedbackFront;
        while (temp != nullptr) {
            if (temp->donorName == donorName) {
                cout << "Error: Feedback from donor " << donorName << " already exists.\n";
                return;
            }
            temp = temp->next;
        }

        cout << "Enter Feedback Message: ";
        string feedbackMessage;
        getline(cin, feedbackMessage);
        FeedbackNode* newFeedback = new FeedbackNode(donorName, feedbackMessage);
        if (feedbackFront == nullptr)
            feedbackFront = feedbackRear = newFeedback;
        else {
            feedbackRear->next = newFeedback;
            feedbackRear = newFeedback;
        }
        ofstream file("feedback.csv", ios::app);
        if (file.is_open()) {
            file << donorName << "," << feedbackMessage << "\n";
            file.close();
        } else {
            cerr << "Error: Unable to write to feedback.csv" << endl;
        }
        cout << "Feedback added successfully!\n";
    }

    // 12. Display Feedback
    void displayFeedback() {
        if (feedbackFront == nullptr) {
            cout << "\nNo feedback data found.\n";
            return;
        }
        cout << "\nFeedback List:\nDonor Name, Feedback Message\n";
        FeedbackNode* temp = feedbackFront;
        while (temp != nullptr) {
            cout << "Donor Name: " << temp->donorName << "\nFeedback: " << temp->feedbackMessage << "\n\n";
            temp = temp->next;
        }
    }

    // ----------------- Login and Admin Menu -----------------
    void login() {
        clearScreen();
        printHeader();
        initializeFiles(); // Ensure files exist

        string username, password;
        bool validLogin = false;
        while (!validLogin) {
            cout << "Enter Username: ";
            cin >> username;
            if (!isValidUsername(username)) {
                cout << "Invalid username! Only alphabets allowed.\n";
                continue;
            }
            cout << "Enter Password: ";
            cin >> password;
            if (!isValidPassword(password)) {
                cout << "Invalid password! Must contain letters and numbers.\n";
                continue;
            }
            if (authenticateAdmin(username, password)) {
                cout << "\nLogin successful!\n";
                validLogin = true;
                adminMenu();
            } else {
                cout << "\nInvalid credentials. Please try again.\n";
            }
        }
    }

    void adminMenu() {
        int choice;
        do {
            clearScreen();
            printHeader();
            cout << "Admin Menu:\n";
            cout << "1. Add Donor\n";
            cout << "2. Display Donors\n";
            cout << "3. Delete Donor\n";
            cout << "4. Add Child\n";
            cout << "5. Display Children\n";
            cout << "6. Add Student\n";
            cout << "7. Display Students\n";
            cout << "8. Delete Student\n";
            cout << "9. Assign Points to Student\n";
            cout << "10. Display Student Rankings\n";
            cout << "11. Add Feedback\n";
            cout << "12. Display Feedback\n";
            cout << "13. Logout\n";
            cout << "\nEnter your choice: ";
            cin >> choice;
            if (cin.fail()) {
                cout << "Invalid choice! Please try again.\n";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                continue;
            }
            switch (choice) {
                case 1: addDonor(); break;
                case 2: displayDonors(); break;
                case 3: deleteDonor(); break;
                case 4: addChild(); break;
                case 5: displayChildren(); break;
                case 6: addStudent(); break;
                case 7: displayStudents(); break;
                case 8: deleteStudent(); break;
                case 9: assignPoints(); break;
                case 10: displayStudentRankings(); break;
                case 11: addFeedback(); break;
                case 12: displayFeedback(); break;
                case 13: cout << "\nLogging out...\n"; break;
                default: cout << "Invalid choice. Try again.\n";
            }
            if (choice != 13) {
                cout << "\nPress Enter to return to the Admin Dashboard...";
                cin.ignore();
                cin.get();
            }
        } while (choice != 13);
    }

    // ----------------- Destructor to Free Memory -----------------
    ~WelfareSystem() {
        while (donorHead) {
            DonorNode* temp = donorHead;
            donorHead = donorHead->next;
            delete temp;
        }
        while (childHead) {
            ChildNode* temp = childHead;
            childHead = childHead->next;
            delete temp;
        }
        while (studentHead) {
            StudentNode* temp = studentHead;
            studentHead = studentHead->next;
            delete temp;
        }
        while (pointsStackTop) {
            PointsStackNode* temp = pointsStackTop;
            pointsStackTop = pointsStackTop->next;
            delete temp;
        }
        while (feedbackFront) {
            FeedbackNode* temp = feedbackFront;
            feedbackFront = feedbackFront->next;
            delete temp;
        }
    }
};

int main() {
    WelfareSystem system;
    cout << "Welcome to the Welfare Management System\n";
    system.login();
    return 0;
}
